#ifndef STDINCLUDE_H
#define STDINCLUDE_H

#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QDir>
#include <QString>
#include <QMessageBox>
#include <QPointF>
#include <QGraphicsSceneMouseEvent>
#include <list>
#include <QThread>
#include <QMainWindow>
#include <QGraphicsScene>
#include <vector>
#include "mapscene.h"
#include "astar.h"
#include "pathstepsthread.h"
#include "mapscene.h"

#endif // STDINCLUDE_H
